public interface Autenticavel {
    boolean autenticar(String senha);
}