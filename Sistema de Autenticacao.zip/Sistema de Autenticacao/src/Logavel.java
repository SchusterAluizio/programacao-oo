public interface Logavel {
    void registrarLog(String operacao);
}
