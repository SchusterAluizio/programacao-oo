public interface Gerenciavel {
    void alterarSenha(String novaSenha);
    void bloquearUsuario();
}
